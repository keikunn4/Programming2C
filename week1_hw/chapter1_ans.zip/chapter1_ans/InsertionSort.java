class InsertionSort {
    private int comparisonNum = 0; // # of comparison
    private int exchangeNum = 0; // # of exchange

    public int getComparisonNum() {
        return comparisonNum;
    }

    public int getExchangeNum() {
        return exchangeNum;
    }

    public int[] sort(int[] data) {
        comparisonNum = 0;
        exchangeNum = 0;

        for (int i = 1; i < data.length; i++) {
            int tmp = data[i];
            int j = i - 1;
            while (j >= 0 && data[j] > tmp) {
                data[j + 1] = data[j];
                j--;
                exchangeNum++;
                comparisonNum++;
            }
            data[j + 1] = tmp;
            if(j>=0){comparisonNum++;}
        }

        return data;
    }
}
