import java.io.StreamTokenizer;
import java.io.FileReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.FileWriter;

class InsertionSortMain {
    static final String INPUT_FILE_NAME = "data.txt";

    public static int countLine(String fileName) {
        int count = 0;
        try {
            FileReader fr = new FileReader(fileName);
            StreamTokenizer st = new StreamTokenizer(fr);
            while (st.nextToken() != StreamTokenizer.TT_EOF) {
                if (st.ttype == StreamTokenizer.TT_NUMBER) {
                    count++;
                }
            }
            fr.close();
        } catch (FileNotFoundException e) {
            System.out.println("text file \"" + fileName + "\" was not found.");
        } catch (IOException e) {
            System.out.println("Error: " + e);
        }
        return count;
    }

    public static int[] readInt(String fileName){
        int count = 0;
        int[] data = new int[countLine(fileName)];
        try {
            FileReader fr = new FileReader(fileName);
            StreamTokenizer st = new StreamTokenizer(fr);
            while (st.nextToken() != StreamTokenizer.TT_EOF) {
                if (st.ttype == StreamTokenizer.TT_NUMBER) {
                    data[count] = (int)st.nval;
                    count++;
                }
            }
            fr.close();
        } catch (FileNotFoundException e) {
            System.out.println("text file \"" + fileName + "\" was not found.");
        } catch (IOException e) {
            System.out.println("Error: " + e);
        }
        return data;
    }

    public static void main(String[] args) {
        int[] data = readInt(INPUT_FILE_NAME);
        InsertionSort is = new InsertionSort();
        data = is.sort(data);

        try {
            FileWriter fw = new FileWriter("340000.txt");

            fw.write("-- Insertion Sort --\n");
            for (int i = 0; i < data.length; i++) {
                fw.write("[" + i + "]: " + data[i] + "\n");
            }

            fw.write("# of comparison: " + is.getComparisonNum() + "\n");
            fw.write("# of exchange: " + is.getExchangeNum() + "\n");

            fw.close();
        } catch (IOException e) {
            System.out.println("Error: " + e);
        }
    }
}